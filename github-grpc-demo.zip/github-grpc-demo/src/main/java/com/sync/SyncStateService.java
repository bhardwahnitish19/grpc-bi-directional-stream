package com.sync;


import io.grpc.stub.StreamObserver;
import io.grpc.sync.Acknowledgement;
import io.grpc.sync.MessageRequest;
import io.grpc.sync.SyncStateGrpc;
import org.lognet.springboot.grpc.GRpcService;

import java.util.concurrent.CompletableFuture;

@GRpcService
public class SyncStateService extends SyncStateGrpc.SyncStateImplBase {

    private SyncManager manager;
    private Configuration config;

    public SyncStateService(SyncManager manager, Configuration config) {
        this.manager = manager;
        this.config = config;
    }

    @Override
    public StreamObserver<MessageRequest> sync(StreamObserver<Acknowledgement> responseObserver) {
        System.out.println("Server received connection request");
        return new StreamObserver<MessageRequest>() {
            @Override
            public void onNext(MessageRequest request) {
                Acknowledgement ack = Acknowledgement.newBuilder().setTxnId(request.getTxnId()).setServerId(config.getClientId()).build();
                MessageRequest clone = MessageRequest.newBuilder().setClientId(config.getClientId()).setTxnId(request.getTxnId()).build();
                CompletableFuture.runAsync(() -> manager.sendMessage(clone));
                responseObserver.onNext(ack);
            }

            @Override
            public void onError(Throwable t) {
                t.printStackTrace();
            }

            @Override
            public void onCompleted() {
                System.out.println("client called on completed on stream, server closes response stream");
                responseObserver.onCompleted();
            }
        };
    }
}

