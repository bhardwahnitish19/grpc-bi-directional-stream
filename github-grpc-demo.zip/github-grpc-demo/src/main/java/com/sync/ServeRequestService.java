package com.sync;

import io.grpc.stub.StreamObserver;
import io.grpc.sync.Acknowledgement;
import io.grpc.sync.MessageRequest;
import io.grpc.sync.ServeRequestGrpc;
import org.lognet.springboot.grpc.GRpcService;

@GRpcService
public class ServeRequestService extends ServeRequestGrpc.ServeRequestImplBase {

    private SyncManager syncManager;

    public ServeRequestService(SyncManager syncManager) {
        this.syncManager = syncManager;
    }

    @Override
    public void newRequest(MessageRequest request, StreamObserver<Acknowledgement> responseObserver) {
        syncManager.startStateSync(request);
        Acknowledgement ack = Acknowledgement.newBuilder().setTxnId(request.getTxnId()).build();
        responseObserver.onNext(ack);
        responseObserver.onCompleted();
    }
}
