package com.sync;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.grpc.sync.Acknowledgement;
import io.grpc.sync.MessageRequest;
import io.grpc.sync.SyncStateGrpc;

import java.util.concurrent.TimeUnit;

public class SyncClient {
    private final ManagedChannel channel;
    private final SyncStateGrpc.SyncStateStub stub;
    private final StreamObserver<MessageRequest> stream;
    public SyncClient(String node) {
        channel = ManagedChannelBuilder.forTarget(node)
                .usePlaintext()
                .keepAliveTime(new Long(2), TimeUnit.DAYS)
                .keepAliveTimeout(new Long(1), TimeUnit.DAYS)
                .keepAliveWithoutCalls(true)
                .build();
        stub = SyncStateGrpc.newStub(channel);
        stream = getStreamObserver();
    }
    private StreamObserver<MessageRequest> getStreamObserver() {
        final StreamObserver<MessageRequest> stream;
        stream = stub.sync(new StreamObserver<>() {
            @Override
            public void onNext(Acknowledgement value) {
                String txnId = value.getTxnId();
                System.out.println("Received message from server");
                String serverId = value.getServerId();

            }

            @Override
            public void onError(Throwable t) {
                t.printStackTrace();
            }

            @Override
            public void onCompleted() {
                System.out.println("Completed");
            }
        });
        return stream;
    }

    public void syncMessage(String node, MessageRequest request) {
        System.out.println("Sending message to:: "+ node);
        stream.onNext(request);
    }

}
