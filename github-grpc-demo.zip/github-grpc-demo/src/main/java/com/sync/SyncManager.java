package com.sync;

import io.grpc.sync.MessageRequest;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class SyncManager {
    private Map<String, SyncClient> client = new HashMap<>();
    private final Configuration  config;

    public SyncManager(Configuration  config) {
        this.config = config;
    }

    public void startStateSync(MessageRequest clone) {
        config.getNodes().forEach(e->{
            SyncClient syncClient = client.get(e);
            if (syncClient== null){
                syncClient = new SyncClient(e);
            }
            MessageRequest gossipRequest = MessageRequest.newBuilder().setTxnId(clone.getTxnId())
                    .setPolicyId(clone.getPolicyId()).setClientId(config.getClientId()).build();
            syncClient.syncMessage(e, gossipRequest);
        });
    }

    public void sendMessage(MessageRequest clone) {
        config.getNodes().forEach(e->{
            SyncClient syncClient = client.get(e);
            if (syncClient== null){
                syncClient = new SyncClient(e);
            }
            MessageRequest gossipRequest = MessageRequest.newBuilder().setTxnId(clone.getTxnId())
                    .setPolicyId(clone.getPolicyId()).setClientId(config.getClientId()).build();
            syncClient.syncMessage(e, gossipRequest);
        });
    }
}
